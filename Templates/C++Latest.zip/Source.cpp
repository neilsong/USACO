#include <bits/stdc++.h>
using namespace std;

int main(void) {
	ifstream fin(".in");
	ofstream fout(".out");
	
	return 0;
}