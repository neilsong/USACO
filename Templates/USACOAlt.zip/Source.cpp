#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <fstream>
#include <iosfwd>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>
#include <array>
using namespace std;



int main(void) {
	ifstream fin(".in");
	ofstream fout(".out");





	return 0;
}